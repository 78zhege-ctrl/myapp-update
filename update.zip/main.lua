-- 如果有更新包，优先加载更新后的脚本（必须放在 require "import" 之前）
local File = luajava.bindClass("java.io.File")
local 更新目录 = activity.getFilesDir().getAbsolutePath() .. "/update"
local 更新主文件 = 更新目录 .. "/main.lua"
if File(更新主文件).exists() then
  activity.setLuaDir(更新目录)
  dofile(更新主文件)
  return
end

require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "com.pretend.eq.view.*"
import "layout"
import "AndLua"
import "xfq"
import "xfc"

-- ========== 全局状态变量 ==========
当前选中进程 = nil
当前选中PID = nil
hasRoot = false
Root详细信息 = ""

-- ========== 智能云更新（静默后台检查）==========
local 更新服务器 = "https://ghproxy.net/https://raw.githubusercontent.com/78zhege-ctrl/myapp-update/main/"
local 备用服务器 = "https://mirror.ghproxy.com/https://raw.githubusercontent.com/78zhege-ctrl/myapp-update/main/"
local 本地版本 = "1.2"

function 检查更新()
    import "android.content.Context"
    local 偏好设置 = activity.getSharedPreferences("update", Context.MODE_PRIVATE)
    local 启动次数 = 偏好设置.getInt("launch_count", 0) + 1
    偏好设置.edit().putInt("launch_count", 启动次数).apply()

    if 启动次数 < 3 then
        return
    end

    local 上次检查 = 偏好设置.getLong("last_check", 0)
    local 失败次数 = 偏好设置.getInt("fail_count", 0)
    local 当前时间 = System.currentTimeMillis()

    local 间隔小时 = 168
    if 失败次数 > 0 then
        local 退避 = {24, 72, 168}
        间隔小时 = 退避[math.min(失败次数, 3)]
    end

    if (当前时间 - 上次检查) < (间隔小时 * 3600000) then
        return
    end

    -- 静默后台检查，使用Http.get（与卡密下载同一套）
    Http.get(更新服务器 .. "version.txt?t=" .. tostring(System.currentTimeMillis()), function(code, content)
        if code == 200 and content then
            local 最新版本 = content:gsub("%s", "")
            偏好设置.edit()
                .putLong("last_check", System.currentTimeMillis())
                .putInt("fail_count", 0)
                .apply()

            if 最新版本 ~= "" and 最新版本 ~= 本地版本 then
                AlertDialog.Builder(activity)
                    .setTitle("发现新版本 v" .. 最新版本)
                    .setMessage("当前版本: v" .. 本地版本 .. "\n是否立即更新？")
                    .setPositiveButton("更新", {onClick=function()
                        下载更新包()
                    end})
                    .setNegativeButton("暂不", nil)
                    .show()
            end
        else
            -- 主地址失败，尝试备用地址
            Http.get(备用服务器 .. "version.txt?t=" .. tostring(System.currentTimeMillis()), function(code2, content2)
                if code2 == 200 and content2 then
                    local 最新版本 = content2:gsub("%s", "")
                    偏好设置.edit()
                        .putLong("last_check", System.currentTimeMillis())
                        .putInt("fail_count", 0)
                        .apply()
                    if 最新版本 ~= "" and 最新版本 ~= 本地版本 then
                        AlertDialog.Builder(activity)
                            .setTitle("发现新版本 v" .. 最新版本)
                            .setMessage("当前版本: v" .. 本地版本 .. "\n是否立即更新？")
                            .setPositiveButton("更新", {onClick=function()
                                下载更新包()
                            end})
                            .setNegativeButton("暂不", nil)
                            .show()
                    end
                else
                    local 新失败次数 = 偏好设置.getInt("fail_count", 0) + 1
                    偏好设置.edit()
                        .putLong("last_check", System.currentTimeMillis())
                        .putInt("fail_count", 新失败次数)
                        .apply()
                end
            end)
        end
    end)
end

-- ========== 手动检查更新（带进度条 + 15秒超时 + 备用地址） ==========
function 手动检查更新()
    import "android.app.ProgressDialog"
    import "android.os.Handler"

    local 检查弹窗 = ProgressDialog(activity)
    检查弹窗.setTitle("检查更新")
    检查弹窗.setMessage("正在连接服务器...")
    检查弹窗.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL)
    检查弹窗.setProgress(0)
    检查弹窗.setMax(100)
    检查弹窗.setCancelable(false)
    检查弹窗.show()

    local 当前进度 = 0
    local 进度Handler = Handler()
    local 进度Runnable = nil
    local 已超时 = false

    进度Runnable = Runnable({
        run = function()
            if 已超时 then return end
            当前进度 = 当前进度 + 3
            if 当前进度 > 85 then 当前进度 = 85 end
            pcall(function() 检查弹窗.setProgress(当前进度) end)
            if 当前进度 < 85 then
                进度Handler.postDelayed(进度Runnable, 300)
            end
        end
    })
    进度Handler.post(进度Runnable)

    -- 15秒强制超时
    local 超时Handler = Handler()
    超时Handler.postDelayed(function()
        已超时 = true
        pcall(function()
            进度Handler.removeCallbacks(进度Runnable)
            检查弹窗.dismiss()
        end)
        AlertDialog.Builder(activity)
            .setTitle("检查超时")
            .setMessage("连接服务器超时，请检查网络或稍后再试。\n\n提示：\n1. 检查网络连接\n2. 尝试开启VPN\n3. 服务器可能暂时不可用")
            .setPositiveButton("确定", nil)
            .show()
    end, 15000)

    -- 尝试主地址
    Http.get(更新服务器 .. "version.txt?t=" .. tostring(System.currentTimeMillis()), function(code, content)
        if 已超时 then return end

        if code == 200 and content then
            pcall(function()
                进度Handler.removeCallbacks(进度Runnable)
                检查弹窗.setProgress(100)
                检查弹窗.dismiss()
            end)

            local 最新版本 = content:gsub("%s", "")
            if 最新版本 ~= "" and 最新版本 ~= 本地版本 then
                AlertDialog.Builder(activity)
                    .setTitle("发现新版本 v" .. 最新版本)
                    .setMessage("当前版本: v" .. 本地版本 .. "\n是否立即更新？")
                    .setPositiveButton("更新", {onClick=function()
                        下载更新包()
                    end})
                    .setNegativeButton("取消", nil)
                    .show()
            else
                AlertDialog.Builder(activity)
                    .setTitle("已是最新版本")
                    .setMessage("当前版本: v" .. 本地版本)
                    .setPositiveButton("确定", nil)
                    .show()
            end
        else
            -- 主地址失败，尝试备用地址
            pcall(function() 检查弹窗.setMessage("主服务器失败，尝试备用...") end)

            Http.get(备用服务器 .. "version.txt?t=" .. tostring(System.currentTimeMillis()), function(code2, content2)
                if 已超时 then return end

                if code2 == 200 and content2 then
                    pcall(function()
                        进度Handler.removeCallbacks(进度Runnable)
                        检查弹窗.setProgress(100)
                        检查弹窗.dismiss()
                    end)

                    local 最新版本 = content2:gsub("%s", "")
                    if 最新版本 ~= "" and 最新版本 ~= 本地版本 then
                        AlertDialog.Builder(activity)
                            .setTitle("发现新版本 v" .. 最新版本)
                            .setMessage("当前版本: v" .. 本地版本 .. "\n是否立即更新？")
                            .setPositiveButton("更新", {onClick=function()
                                下载更新包()
                            end})
                            .setNegativeButton("取消", nil)
                            .show()
                    else
                        AlertDialog.Builder(activity)
                            .setTitle("已是最新版本")
                            .setMessage("当前版本: v" .. 本地版本)
                            .setPositiveButton("确定", nil)
                            .show()
                    end
                else
                    pcall(function()
                        进度Handler.removeCallbacks(进度Runnable)
                        检查弹窗.dismiss()
                    end)
                    AlertDialog.Builder(activity)
                        .setTitle("检查失败")
                        .setMessage("所有服务器均无法连接。\n状态码1: " .. tostring(code) .. "\n状态码2: " .. tostring(code2) .. "\n\n请检查网络或开启VPN后重试。")
                        .setPositiveButton("确定", nil)
                        .show()
                end
            end)
        end
    end)
end

-- ========== 下载更新包（带进度条 - 每1KB+1% + 备用地址） ==========
function 下载更新包()
    import "android.app.ProgressDialog"
    import "java.net.URL"
    import "java.io.File"
    import "java.io.FileOutputStream"
    import "java.io.BufferedInputStream"
    import "java.lang.Thread"

    local 进度 = ProgressDialog(activity)
    进度.setTitle("更新中")
    进度.setMessage("开始下载...")
    进度.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL)
    进度.setProgress(0)
    进度.setMax(100)
    进度.setCancelable(false)
    进度.show()

    local 下载路径 = activity.getFilesDir().getAbsolutePath() .. "/update.zip"
    local 当前服务器 = 更新服务器

    task(function(服务器, 进度对象)
        local ok = false
        local 错误信息 = ""

        local 成功, 结果 = pcall(function()
            local oldFile = File(下载路径)
            if oldFile.exists() then oldFile.delete() end

            local url = URL(服务器 .. "update.zip")
            local conn = url.openConnection()
            conn.setConnectTimeout(30000)
            conn.setReadTimeout(30000)
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10)")

            local total = conn.getContentLength()
            local input = BufferedInputStream(conn.getInputStream())
            local output = FileOutputStream(下载路径)

            local buffer = byte[4096]
            local downloaded = 0
            local count = 0
            local lastPercent = 0
            local lastUpdateTime = System.currentTimeMillis()

            while true do
                count = input.read(buffer)
                if count == -1 then break end
                output.write(buffer, 0, count)
                downloaded = downloaded + count

                -- 每下载1KB进度+1%，确保肉眼可见走动
                local percent = math.min(math.floor(downloaded / 1024), 99)
                if percent > lastPercent then
                    lastPercent = percent
                    local now = System.currentTimeMillis()
                    -- 每200ms最多更新一次UI，避免卡顿
                    if now - lastUpdateTime > 200 then
                        lastUpdateTime = now
                        activity.runOnUiThread(function()
                            进度对象.setProgress(percent)
                            if total > 0 then
                                进度对象.setMessage("正在下载 " .. percent .. "% (" .. math.floor(downloaded/1024) .. "KB / " .. math.floor(total/1024) .. "KB)")
                            else
                                进度对象.setMessage("正在下载 " .. percent .. "% (" .. math.floor(downloaded/1024) .. "KB)")
                            end
                        end)
                    end
                end
            end

            output.flush()
            output.close()
            input.close()

            -- 下载完成，跳到100%
            activity.runOnUiThread(function()
                进度对象.setProgress(100)
                进度对象.setMessage("下载完成，准备安装...")
            end)

            return true
        end)

        if not 成功 then
            错误信息 = tostring(结果)
        end

        return {下载路径, 成功, 错误信息}
    end, function(结果)
        local 路径 = 结果[1]
        local 成功 = 结果[2]
        local 错误 = 结果[3]

        if 成功 then
            解压更新包(路径, 进度)
        else
            -- 主地址下载失败，尝试备用地址
            进度.setMessage("主服务器失败，尝试备用...")
            进度.setProgress(0)

            task(function(备用地址, 进度对象2)
                local ok2 = false
                local 错误信息2 = ""

                local 成功2, 结果2 = pcall(function()
                    local oldFile = File(下载路径)
                    if oldFile.exists() then oldFile.delete() end

                    local url = URL(备用地址 .. "update.zip")
                    local conn = url.openConnection()
                    conn.setConnectTimeout(30000)
                    conn.setReadTimeout(30000)
                    conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10)")

                    local total = conn.getContentLength()
                    local input = BufferedInputStream(conn.getInputStream())
                    local output = FileOutputStream(下载路径)

                    local buffer = byte[4096]
                    local downloaded = 0
                    local count = 0
                    local lastPercent = 0
                    local lastUpdateTime = System.currentTimeMillis()

                    while true do
                        count = input.read(buffer)
                        if count == -1 then break end
                        output.write(buffer, 0, count)
                        downloaded = downloaded + count

                        local percent = math.min(math.floor(downloaded / 1024), 99)
                        if percent > lastPercent then
                            lastPercent = percent
                            local now = System.currentTimeMillis()
                            if now - lastUpdateTime > 200 then
                                lastUpdateTime = now
                                activity.runOnUiThread(function()
                                    进度对象2.setProgress(percent)
                                    if total > 0 then
                                        进度对象2.setMessage("备用下载 " .. percent .. "% (" .. math.floor(downloaded/1024) .. "KB / " .. math.floor(total/1024) .. "KB)")
                                    else
                                        进度对象2.setMessage("备用下载 " .. percent .. "% (" .. math.floor(downloaded/1024) .. "KB)")
                                    end
                                end)
                            end
                        end
                    end

                    output.flush()
                    output.close()
                    input.close()

                    activity.runOnUiThread(function()
                        进度对象2.setProgress(100)
                        进度对象2.setMessage("下载完成，准备安装...")
                    end)

                    return true
                end)

                if not 成功2 then
                    错误信息2 = tostring(结果2)
                end

                return {下载路径, 成功2, 错误信息2}
            end, function(结果2)
                local 路径2 = 结果2[1]
                local 成功2 = 结果2[2]
                local 错误2 = 结果2[3]

                if 成功2 then
                    解压更新包(路径2, 进度)
                else
                    进度.dismiss()
                    AlertDialog.Builder(activity)
                        .setTitle("下载失败")
                        .setMessage("所有服务器均无法下载更新包。\n\n主服务器错误: " .. 错误 .. "\n备用服务器错误: " .. 错误2 .. "\n\n请检查网络或开启VPN后重试。")
                        .setPositiveButton("确定", nil)
                        .show()
                end
            end, 备用服务器, 进度)
        end
    end, 当前服务器, 进度)
end

-- ========== 解压更新包（带进度条） ==========
function 解压更新包(路径, 进度)
    import "java.util.zip.ZipFile"
    import "java.io.File"
    import "java.io.FileOutputStream"
    import "java.lang.Thread"

    task(function(路径, 进度对象)
        local 项目目录 = activity.getFilesDir().getAbsolutePath() .. "/update"
        local ok = false
        local 错误信息 = ""

        local 成功, 结果 = pcall(function()
            local dir = File(项目目录)
            if dir.exists() then
                local files = dir.listFiles()
                if files then
                    for i = 0, #files - 1 do
                        files[i].delete()
                    end
                end
            else
                dir.mkdirs()
            end

            local zip = ZipFile(路径)
            local entries = zip.entries()

            local entryList = {}
            while entries.hasMoreElements() do
                table.insert(entryList, entries.nextElement())
            end

            local total = #entryList

            for i, entry in ipairs(entryList) do
                local 文件名 = entry.getName()
                local 输出文件 = File(项目目录 .. "/" .. 文件名)

                if not 输出文件.getParentFile().exists() then
                    输出文件.getParentFile().mkdirs()
                end

                local input = zip.getInputStream(entry)
                local output = FileOutputStream(输出文件)
                local buffer = byte[1024]
                local count = 0
                while true do
                    count = input.read(buffer)
                    if count == -1 then break end
                    output.write(buffer, 0, count)
                end
                output.close()
                input.close()

                local percent = math.floor(i * 100 / total)
                activity.runOnUiThread(function()
                    进度对象.setProgress(percent)
                    进度对象.setMessage("正在安装 " .. i .. " / " .. total .. " (" .. percent .. "%)")
                end)

                Thread.sleep(50)
            end

            zip.close()
            return true
        end)

        if not 成功 then
            错误信息 = tostring(结果)
        end

        pcall(function()
            File(路径).delete()
        end)

        return {成功, 错误信息}
    end, function(结果)
        local 成功 = 结果[1]
        local 错误 = 结果[2]
        进度.dismiss()

        if 成功 then
            AlertDialog.Builder(activity)
            .setTitle("更新完成")
            .setMessage("重启应用后生效")
            .setPositiveButton("立即重启", {onClick=function()
                import "android.content.Intent"
                local intent = activity.getPackageManager().getLaunchIntentForPackage(activity.getPackageName())
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                activity.startActivity(intent)
                activity.finish()
            end})
            .show()
        else
            Toast.makeText(activity, "安装失败: " .. 错误, Toast.LENGTH_LONG).show()
        end
    end, 路径, 进度)
end

-- 启动2秒后在后台静默检查
import "android.os.Handler"
Handler().postDelayed(function()
    检查更新()
end, 2000)
-- ========== 云更新结束 ==========

activity.setTheme(R.Theme_Blue)
activity.setContentView(loadlayout(layout))
activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS).setStatusBarColor(0xFF566B79)

activity.ActionBar.hide()

-- UI进入动画
import "android.animation.ObjectAnimator"
import "android.animation.AnimatorSet"
import "android.view.animation.BounceInterpolator"

local rootView = activity.findViewById(android.R.id.content).getChildAt(0)
rootView.setAlpha(0)
rootView.setScaleX(0.5)
rootView.setScaleY(0.5)

local alphaAnim = ObjectAnimator.ofFloat(rootView, "alpha", {0, 1})
local scaleXAnim = ObjectAnimator.ofFloat(rootView, "scaleX", {0.5, 1})
local scaleYAnim = ObjectAnimator.ofFloat(rootView, "scaleY", {0.5, 1})

local animatorSet = AnimatorSet()
animatorSet.playTogether({alphaAnim, scaleXAnim, scaleYAnim})
animatorSet.setDuration(1000)
animatorSet.setInterpolator(BounceInterpolator())
animatorSet.start()

-- 悬浮窗权限（适配华为 EMUI / HarmonyOS）
import "android.content.*"
import "android.provider.Settings"
import "android.os.Build"
import "java.util.*"

function 检查悬浮窗权限()
    if Build.VERSION.SDK_INT >= 23 then
        local canDraw = Settings.canDrawOverlays(this)
        if not canDraw then
            AlertDialog.Builder(activity)
            .setTitle("需要悬浮窗权限")
            .setMessage("华为/荣耀系统请在「设置 → 应用和服务 → 应用管理 → 本应用 → 权限 → 悬浮窗」中开启权限。\n\n部分 HarmonyOS 版本需要同时开启「后台弹窗」权限。")
            .setPositiveButton("去开启", {onClick=function(v)
                local intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
                intent.setData(Uri.parse("package:" .. activity.getPackageName()))
                local ok = pcall(function()
                    activity.startActivityForResult(intent, 100)
                end)
                if not ok then
                    local intent2 = Intent("android.settings.APPLICATION_DETAILS_SETTINGS")
                    intent2.setData(Uri.parse("package:" .. activity.getPackageName()))
                    pcall(function() activity.startActivity(intent2) end)
                    Toast.makeText(activity, "请手动找到「悬浮窗」权限并开启", Toast.LENGTH_LONG).show()
                end
            end})
            .setNegativeButton("取消", nil)
            .show()
            return false
        end
    end
    return true
end

检查悬浮窗权限()

-- 悬浮窗设置
wmManager = activity.getSystemService(Context.WINDOW_SERVICE)
wmParams = WindowManager.LayoutParams()

if tonumber(Build.VERSION.SDK) >= 26 then
  wmParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
else
  wmParams.type = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
end

import "android.graphics.PixelFormat"
wmParams.format = PixelFormat.RGBA_8888
wmParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE 
               | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
wmParams.gravity = Gravity.LEFT | Gravity.TOP
wmParams.x = activity.getWidth()/6
wmParams.y = activity.getHeight()/5
wmParams.width = WindowManager.LayoutParams.WRAP_CONTENT
wmParams.height = WindowManager.LayoutParams.WRAP_CONTENT

悬浮球 = loadlayout(xfq)
悬浮窗 = loadlayout(xfc)

-- 悬浮窗弹性动画
function 播放悬浮窗动画(view)
  import "android.animation.ObjectAnimator"
  import "android.animation.AnimatorSet"
  import "android.view.animation.BounceInterpolator"
  view.setAlpha(0)
  view.setScaleX(0.3)
  view.setScaleY(0.3)
  local a = ObjectAnimator.ofFloat(view, "alpha", {0, 1})
  local sx = ObjectAnimator.ofFloat(view, "scaleX", {0.3, 1})
  local sy = ObjectAnimator.ofFloat(view, "scaleY", {0.3, 1})
  local set = AnimatorSet()
  set.playTogether({a, sx, sy})
  set.setDuration(800)
  set.setInterpolator(BounceInterpolator())
  set.start()
end

function 放大()
  wmManager.addView(悬浮窗, wmParams)
  播放悬浮窗动画(悬浮窗)
  wmManager.removeView(悬浮球)
  检测Root()
end

缩小.onClick = function(v)
  wmManager.removeView(悬浮窗)
  wmManager.addView(悬浮球, wmParams)
end

关闭悬浮窗.onClick = function(v)
  pcall(function() wmManager.removeView(悬浮窗) end)
  pcall(function() wmManager.removeView(悬浮球) end)
  Ma = false
  QQ开关.setChecked(false)
  Toast.makeText(activity, "悬浮窗已关闭", Toast.LENGTH_SHORT).show()
end

图标.onTouch = function(v, event)
  if event.getAction() == MotionEvent.ACTION_DOWN then
    firstX = event.getRawX()
    firstY = event.getRawY()
    wmX = wmParams.x
    wmY = wmParams.y
  elseif event.getAction() == MotionEvent.ACTION_MOVE then
    wmParams.x = wmX + (event.getRawX() - firstX)
    wmParams.y = wmY + (event.getRawY() - firstY)
    wmManager.updateViewLayout(悬浮球, wmParams)
  end
  return false
end

拖动.onTouch = function(v, event)
  if event.getAction() == MotionEvent.ACTION_DOWN then
    firstX = event.getRawX()
    firstY = event.getRawY()
    wmX = wmParams.x
    wmY = wmParams.y
  elseif event.getAction() == MotionEvent.ACTION_MOVE then
    wmParams.x = wmX + (event.getRawX() - firstX)
    wmParams.y = wmY + (event.getRawY() - firstY)
    wmManager.updateViewLayout(悬浮窗, wmParams)
  end
  return false
end

winParams = 卡片.getLayoutParams()
win_worh.onTouch = function(v, event)
  if event.getAction() == MotionEvent.ACTION_DOWN then
    firstX = event.getRawX()
    firstY = event.getRawY()
    wmX = winParams.width
    wmY = winParams.height
  elseif event.getAction() == MotionEvent.ACTION_MOVE then
    winParams.width = wmX + (event.getRawX() - firstX)
    winParams.height = wmY + (event.getRawY() - firstY)
    卡片.setLayoutParams(winParams)
  end
  return true
end

-- ========== 强化Root检测（适配所有框架与设备） ==========
function 检测Root()
  import "java.io.File"
  import "java.lang.Runtime"
  import "java.io.BufferedReader"
  import "java.io.InputStreamReader"
  import "android.content.pm.PackageManager"

  local 有Root = false
  local 类型 = "未获取"
  local 详情 = ""

  -- 1. 检查常见su二进制文件
  local su路径表 = {
    "/system/bin/su",
    "/system/xbin/su",
    "/sbin/su",
    "/su/bin/su",
    "/system/sbin/su",
    "/vendor/bin/su",
    "/system/sd/xbin/su",
    "/data/local/xbin/su",
    "/data/local/bin/su",
    "/system/app/Superuser.apk",
    "/system/xbin/daemonsu",
    "/system/xbin/sugote",
    "/system/xbin/sugote-mksh",
    "/system/bin/su.back",
    "/system/xbin/su.back",
    "/system/bin/.ext/.su",
    "/system/xbin/.ext/.su",
    "/system/etc/init.d/99SuperSUDaemon",
    "/system/etc/.has_su_daemon",
    "/system/etc/.installed_su_daemon",
    "/dev/com.koushikdutta.superuser.daemon/",
    "/data/adb/magisk/magisk",
    "/data/adb/magisk/busybox",
    "/sbin/.magisk",
    "/dev/.magisk.unblock",
    "/data/adb/ksu/bin/su",
    "/data/adb/ksu/bin/ksud",
    "/data/adb/ksu/busybox",
    "/data/adb/ap/bin/su",
    "/data/adb/ap/bin/apd",
    "/data/user/0/com.koushikdutta.superuser",
    "/data/user/0/com.topjohnwu.magisk"
  }

  for _, 路径 in ipairs(su路径表) do
    if File(路径).exists() then
      有Root = true
      if 路径:find("magisk") then 类型 = "Magisk"
      elseif 路径:find("ksu") then 类型 = "KernelSU"
      elseif 路径:find("ap") then 类型 = "APatch"
      elseif 路径:find("daemonsu") then 类型 = "SuperSU"
      else 类型 = "系统Root" end
      详情 = 路径
      break
    end
  end

  -- 2. 尝试执行su命令并验证输出
  if not 有Root then
    local 测试命令 = {
      "su -c 'echo root_test_ok'",
      "su -c 'id'",
      "su -c 'whoami'"
    }
    for _, 命令 in ipairs(测试命令) do
      local 成功, 结果 = pcall(function()
        local process = Runtime.getRuntime().exec(命令)
        local 退出码 = process.waitFor()
        if 退出码 == 0 then
          local reader = BufferedReader(InputStreamReader(process.getInputStream()))
          local 输出 = reader.readLine() or ""
          reader.close()
          if 输出:find("root") or 输出:find("root_test_ok") or 输出:find("0") then
            return true
          end
        end
        pcall(function() process.getErrorStream().close() end)
        pcall(function() process.getOutputStream().close() end)
        return false
      end)
      if 成功 and 结果 then
        有Root = true
        类型 = "Shell Root"
        详情 = 命令
        break
      end
    end
  end

  -- 3. 检查Magisk特定属性
  if not 有Root then
    pcall(function()
      local process = Runtime.getRuntime().exec("getprop magisk.version")
      if process.waitFor() == 0 then
        local reader = BufferedReader(InputStreamReader(process.getInputStream()))
        local 版本 = reader.readLine()
        reader.close()
        if 版本 and 版本 ~= "" and 版本 ~= "null" then
          有Root = true
          类型 = "Magisk v" .. 版本
        end
      end
    end)
  end

  -- 4. 检查KernelSU特定属性
  if not 有Root then
    pcall(function()
      local process = Runtime.getRuntime().exec("getprop ro.boot.kernelsu")
      if process.waitFor() == 0 then
        local reader = BufferedReader(InputStreamReader(process.getInputStream()))
        local 值 = reader.readLine()
        reader.close()
        if 值 and (值 == "true" or 值 == "1") then
          有Root = true
          类型 = "KernelSU"
        end
      end
    end)
  end

  -- 5. 检查已安装的Root管理器/框架应用
  if not 有Root then
    local root应用表 = {
      "com.koushikdutta.superuser",
      "com.koushikdutta.rommanager",
      "com.koushikdutta.rommanager.license",
      "com.dimonvideo.luckypatcher",
      "com.chelpus.lackypatch",
      "com.ramdroid.appquarantine",
      "com.ramdroid.appquarantinepro",
      "com.topjohnwu.magisk",
      "me.weishu.exp",
      "io.va.exposed",
      "org.lsposed.manager",
      "com.github.tiann",
      "top.canyie.dreamland",
      "com.lody.virtual",
      "com.exposed.lspatch",
      "io.github.huskydg.magisk"
    }
    local pm = activity.getPackageManager()
    for _, 包名 in ipairs(root应用表) do
      pcall(function()
        pm.getPackageInfo(包名, 0)
        有Root = true
        类型 = "框架/Root工具"
        详情 = 包名
      end)
      if 有Root then break end
    end
  end

  -- 6. 进程内存扫描（检测框架注入）
  if not 有Root then
    pcall(function()
      local mapsFile = File("/proc/self/maps")
      if mapsFile.exists() then
        local reader = BufferedReader(InputStreamReader(Runtime.getRuntime().exec("cat /proc/self/maps").getInputStream()))
        local line = reader.readLine()
        while line do
          if line:find("Xposed") or line:find("LSPosed") or line:find("edxp") or line:find("lspd") or line:find("taichi") or line:find("太极") then
            有Root = true
            类型 = "框架注入 (内存检测)"
            详情 = line
            break
          end
          line = reader.readLine()
        end
        reader.close()
      end
    end)
  end

  -- 7. ClassLoader 检测 Xposed/LSPosed
  if not 有Root then
    pcall(function()
      local classLoader = activity.getClass().getClassLoader()
      local xposedClass = classLoader.loadClass("de.robv.android.xposed.XposedBridge")
      if xposedClass then
        有Root = true
        类型 = "Xposed 框架"
      end
    end)
    pcall(function()
      local classLoader = activity.getClass().getClassLoader()
      local lsposedClass = classLoader.loadClass("org.lsposed.lspd.core.Main")
      if lsposedClass then
        有Root = true
        类型 = "LSPosed 框架"
      end
    end)
  end

  -- 8. 华为HarmonyOS/EMUI特殊检测
  pcall(function()
    local process = Runtime.getRuntime().exec("getprop ro.build.version.emui")
    if process.waitFor() == 0 then
      local reader = BufferedReader(InputStreamReader(process.getInputStream()))
      local emui版本 = reader.readLine()
      reader.close()
      if emui版本 and emui版本 ~= "" then
        if not 有Root then
          local 华为路径 = {
            "/system/xbin/su",
            "/system/bin/su",
            "/vendor/xbin/su",
            "/hw_product/bin/su",
            "/system/bin/hw/su"
          }
          for _, 路径 in ipairs(华为路径) do
            if File(路径).exists() then
              有Root = true
              类型 = "HarmonyOS/EMUI Root"
              详情 = 路径
              break
            end
          end
        end
        if not 有Root then
          local process2 = Runtime.getRuntime().exec("su -c 'echo harmony_ok'")
          if process2.waitFor() == 0 then
            local reader2 = BufferedReader(InputStreamReader(process2.getInputStream()))
            local 输出2 = reader2.readLine()
            reader2.close()
            if 输出2 == "harmony_ok" then
              有Root = true
              类型 = "HarmonyOS/EMUI Root"
            end
          end
        end
      end
    end
  end)

  -- 9. 检查环境变量
  if not 有Root then
    pcall(function()
      local process = Runtime.getRuntime().exec("su -c 'printenv PATH'")
      if process.waitFor() == 0 then
        local reader = BufferedReader(InputStreamReader(process.getInputStream()))
        local path变量 = reader.readLine()
        reader.close()
        if path变量 and (path变量:find("magisk") or path变量:find("ksu") or path变量:find("apatch")) then
          有Root = true
          类型 = "环境Root"
        end
      end
    end)
  end

  hasRoot = 有Root
  Root详细信息 = 类型 .. " " .. 详情

  if 有Root then
    Root状态.setText(类型 .. " ✓")
    Root状态.setTextColor(0xFF00FF00)
  else
    Root状态.setText("未获取 ✗")
    Root状态.setTextColor(0xFFFF0000)
  end

  return 有Root
end

-- QQ开关：原生Switch
QQ开关.setOnCheckedChangeListener{
  onCheckedChanged=function(view, isChecked)
    if isChecked then
      import "android.content.Intent"
      import "android.content.pm.PackageManager"
      import "android.net.Uri"
      local pm = activity.getPackageManager()
      local qqPackages = {
        "com.tencent.mobileqq",
        "com.tencent.mobileqqi",
        "com.tencent.qqlite"
      }
      local qqFound = false
      for i, pkg in ipairs(qqPackages) do
        local qqIntent = pm.getLaunchIntentForPackage(pkg)
        if qqIntent then
          qqIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
          qqIntent.addFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
          local ok, err = pcall(function()
            activity.startActivity(qqIntent)
          end)
          if ok then
            qqFound = true
            Toast.makeText(activity, "正在打开QQ", Toast.LENGTH_SHORT).show()
            break
          end
        end
      end
      if not qqFound then
        local uriIntent = Intent(Intent.ACTION_VIEW)
        uriIntent.setData(Uri.parse("mqq://"))
        uriIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        local resolve = pm.resolveActivity(uriIntent, 0)
        if resolve then
          local ok2, err2 = pcall(function()
            activity.startActivity(uriIntent)
          end)
          if ok2 then
            qqFound = true
            Toast.makeText(activity, "正在打开QQ", Toast.LENGTH_SHORT).show()
          end
        end
      end
      if not qqFound then
        local webIntent = Intent(Intent.ACTION_VIEW)
        webIntent.setData(Uri.parse("https://im.qq.com"))
        webIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        pcall(function()
          activity.startActivity(webIntent)
        end)
        Toast.makeText(activity, "未安装QQ，已跳转官网", Toast.LENGTH_SHORT).show()
        QQ开关.setChecked(false)
      end
    end
  end
}

-- ========== 选进程修复（真正获取进程列表，需Root） ==========
选进程.onClick = function(v)
  if not hasRoot then
    Toast.makeText(activity, "❌ 请先获取Root权限后再选择进程\n\n支持: Magisk | KernelSU | APatch | 太极 | 两仪 | 其他框架", Toast.LENGTH_LONG).show()
    return
  end

  local 进度 = ProgressDialog.show(activity, "请稍候", "正在通过Root获取进程列表...", true, false)

  task(function()
    import "java.lang.Runtime"
    import "java.io.BufferedReader"
    import "java.io.InputStreamReader"

    local 全部进程 = {}
    local 推荐进程 = {}
    local 获取成功 = false

    -- 方法1: ps -A
    pcall(function()
      local process = Runtime.getRuntime().exec("su -c 'ps -A -o PID,NAME -k PID'")
      local reader = BufferedReader(InputStreamReader(process.getInputStream()))
      reader.readLine()
      local line = reader.readLine()
      while line do
        local pid, name = line:match("^%s*(%d+)%s+(.+)$")
        if pid and name and #name > 0 then
          table.insert(全部进程, {pid=tonumber(pid), name=name})
        end
        line = reader.readLine()
      end
      reader.close()
      process.waitFor()
      获取成功 = true
    end)

    -- 方法2: ps
    if not 获取成功 or #全部进程 == 0 then
      pcall(function()
        local process = Runtime.getRuntime().exec("su -c 'ps -o PID,NAME -k PID'")
        local reader = BufferedReader(InputStreamReader(process.getInputStream()))
        reader.readLine()
        local line = reader.readLine()
        while line do
          local pid, name = line:match("^%s*(%d+)%s+(.+)$")
          if pid and name and #name > 0 then
            table.insert(全部进程, {pid=tonumber(pid), name=name})
          end
          line = reader.readLine()
        end
        reader.close()
        process.waitFor()
        获取成功 = true
      end)
    end

    -- 方法3: /proc 遍历
    if not 获取成功 or #全部进程 == 0 then
      pcall(function()
        local cmd = 'su -c "for f in $(ls /proc | grep \'^[0-9]\'); do if [ -f /proc/$f/cmdline ]; then c=$(cat /proc/$f/cmdline); if [ -n \"$c\" ]; then echo \"$f|$c\"; fi; fi; done"'
        local process = Runtime.getRuntime().exec(cmd)
        local reader = BufferedReader(InputStreamReader(process.getInputStream()))
        local line = reader.readLine()
        while line do
          local pid, name = line:match("^(%d+)|(.*)$")
          if pid and name and #name > 0 then
            local entry = {pid=tonumber(pid), name=name}
            table.insert(全部进程, entry)
            local lowerName = name:lower()
            if lowerName:find("tencent") or lowerName:find("qq") or lowerName:find("wechat") then
              table.insert(推荐进程, entry)
            end
          end
          line = reader.readLine()
        end
        reader.close()
        process.waitFor()
        获取成功 = true
      end)
    end

    return {全部进程, 推荐进程, 获取成功}
  end, function(结果)
    pcall(function() 进度.dismiss() end)

    local 全部进程 = 结果[1]
    local 推荐进程 = 结果[2]
    local 成功 = 结果[3]

    if not 成功 or #全部进程 == 0 then
      Toast.makeText(activity, "❌ 获取进程列表失败\n可能原因：\n1. Root权限未真正生效\n2. 系统限制了/proc访问\n3. su命令执行异常\n\n请尝试切换Root方案（Magisk/KernelSU/APatch）", Toast.LENGTH_LONG).show()
      return
    end

    local 显示文本 = {}
    local 对应数据 = {}
    local 索引 = 0

    if #推荐进程 > 0 then
      table.insert(显示文本, "★★★ 推荐进程 ★★★")
      对应数据[索引] = nil
      索引 = 索引 + 1
      for _, proc in ipairs(推荐进程) do
        table.insert(显示文本, "▶ " .. proc.name .. "  [PID:" .. proc.pid .. "]")
        对应数据[索引] = proc
        索引 = 索引 + 1
      end
      table.insert(显示文本, "—————— 全部进程 ——————")
      对应数据[索引] = nil
      索引 = 索引 + 1
    end

    for _, proc in ipairs(全部进程) do
      table.insert(显示文本, proc.name .. "  [PID:" .. proc.pid .. "]")
      对应数据[索引] = proc
      索引 = 索引 + 1
    end

    local builder = AlertDialog.Builder(activity)
    builder.setTitle("选择注入目标 (共" .. #全部进程 .. "个进程)")

    local adapter = ArrayAdapter(activity, android.R.layout.simple_list_item_1)
    for _, text in ipairs(显示文本) do
      adapter.add(text)
    end

    builder.setAdapter(adapter, {
      onClick = function(dialog, which)
        local proc = 对应数据[which]
        if proc then
          当前选中进程 = proc.name
          当前选中PID = proc.pid
          local btnText = v.getChildAt(0)
          if btnText then
            local display = proc.name
            if #display > 10 then
              display = display:sub(1, 8) .. ".."
            end
            btnText.setText(display)
          end
          Toast.makeText(activity, "✅ 已选择进程\n名称: " .. proc.name .. "\nPID: " .. proc.pid, Toast.LENGTH_SHORT).show()
        end
      end
    })

    builder.setNegativeButton("取消", nil)
    builder.show()
  end)
end

-- 手动检查更新按钮
检查更新.onClick = function(v)
  手动检查更新()
end

-- ========== 卡密验证系统（GitHub远程卡密后台）==========
import "android.content.Context"
local 卡密存储 = activity.getSharedPreferences("key_auth", Context.MODE_PRIVATE)
local 已保存卡密 = 卡密存储.getString("auth_key", "")
local 卡密过期 = 卡密存储.getLong("expires", 0)
Ma = false

local 远程卡密列表 = {}
local 卡密已加载 = false

function 解析卡密文本(content)
    local 列表 = {}
    if not content or content == "" then return 列表 end
    local newline = string.char(10)
    local start = 1
    while true do
        local pos = content:find(newline, start, true)
        local line
        if pos then
            line = content:sub(start, pos - 1)
            start = pos + 1
        else
            line = content:sub(start)
            if line == "" then break end
            start = #content + 1
        end
        if line:sub(-1) == string.char(13) then
            line = line:sub(1, -2)
        end
        if not line:find("^#") and not line:find("^%s*$") then
            local key, expires, max = line:match("^([^|]+)|([^|]+)|(%d+)$")
            if key then
                key = key:gsub("%s", "")
                expires = expires:gsub("%s", "")
                列表[key] = {expires = expires, maxDevices = tonumber(max)}
            end
        end
        if not pos then break end
    end
    return 列表
end

function 下载卡密列表()
    local 随机数 = tostring(math.random(100000, 999999))
    local url = "https://ghproxy.net/https://raw.githubusercontent.com/78zhege-ctrl/myapp-update/main/keys.txt?t=" .. 随机数
    Http.get(url, function(code, content)
        if code == 200 and content and content ~= "" then
            远程卡密列表 = 解析卡密文本(content)
            卡密已加载 = true
            local 数量 = 0
            for _ in pairs(远程卡密列表) do 数量 = 数量 + 1 end
            print("卡密同步成功，共 " .. 数量 .. " 条")
        else
            print("卡密下载失败，使用内置默认")
            远程卡密列表 = {
                ["810520"] = {expires = "2099-12-31", maxDevices = 99},
                ["TEMP01"] = {expires = "2026-07-14", maxDevices = 1},
                ["TEMP02"] = {expires = "2026-07-14", maxDevices = 1}
            }
            卡密已加载 = true
        end
    end)
end

function 卡密有效(卡密)
    local info = 远程卡密列表[卡密]
    if not info then return false, "卡密不存在", 0, 0 end
    local 过期毫秒 = 0
    if info.expires and info.expires ~= "" then
        local year, month, day = info.expires:match("(%d+)-(%d+)-(%d+)")
        if year then
            local expireTime = os.time({year=tonumber(year), month=tonumber(month), day=tonumber(day), hour=23, min=59, sec=59})
            if expireTime < os.time() then
                return false, "卡密已过期", 0, 0
            end
            过期毫秒 = expireTime * 1000
        end
    end
    if 过期毫秒 == 0 then
        过期毫秒 = System.currentTimeMillis() + 30 * 86400000
    end
    return true, "有效", info.maxDevices or 1, 过期毫秒
end

function 本地卡密有效()
    if 已保存卡密 == "" then return false end
    if 卡密过期 > 0 and 卡密过期 < System.currentTimeMillis() then
        return false
    end
    if not 卡密已加载 then
        if 卡密过期 > System.currentTimeMillis() then
            return true
        end
        return false
    end
    local 有效, 信息, 最大设备, 真实过期 = 卡密有效(已保存卡密)
    if 有效 and 真实过期 ~= 卡密过期 then
        卡密过期 = 真实过期
        卡密存储.edit().putLong("expires", 真实过期).apply()
    end
    return 有效
end

下载卡密列表()

-- ========== 卡密倒计时系统 ==========
import "android.os.Looper"
全局Handler = Handler(Looper.getMainLooper())
倒计时Runnable = nil

function 更新卡密倒计时()
    pcall(function()
        if not 卡密倒计时 then return end
        if 已保存卡密 == "" or 卡密过期 <= 0 then
            卡密倒计时.setText("卡密剩余: 未登录")
            卡密倒计时.setTextColor(0xFFFF0000)
            return
        end
        local 剩余 = 卡密过期 - System.currentTimeMillis()
        if 剩余 <= 0 then
            卡密倒计时.setText("卡密已过期")
            卡密倒计时.setTextColor(0xFFFF0000)
            if Ma then
                pcall(function() wmManager.removeView(悬浮球) end)
                Ma = false
                Toast.makeText(activity, "卡密已过期，请重新登录", Toast.LENGTH_LONG).show()
            end
            return
        end
        local 天 = math.floor(剩余 / 86400000)
        local 时 = math.floor((剩余 % 86400000) / 3600000)
        local 分 = math.floor((剩余 % 3600000) / 60000)
        local 秒 = math.floor((剩余 % 60000) / 1000)
        卡密倒计时.setText(string.format("剩余: %d天%02d:%02d:%02d", 天, 时, 分, 秒))
        if 天 < 1 then
            卡密倒计时.setTextColor(0xFFFF0000)
        else
            卡密倒计时.setTextColor(0xFF00FF00)
        end
    end)
end

function 启动卡密倒计时()
    if 倒计时Runnable then
        全局Handler.removeCallbacks(倒计时Runnable)
    end
    倒计时Runnable = Runnable({
        run = function()
            更新卡密倒计时()
            全局Handler.postDelayed(倒计时Runnable, 1000)
        end
    })
    全局Handler.post(倒计时Runnable)
end

pcall(function()
    if 本地卡密有效() then
        启动卡密倒计时()
    end
end)

-- ========== 登录/解绑按钮 ==========
开启.onClick = function()
    if Ma == true then
        pcall(function() wmManager.removeView(悬浮球) end)
        Ma = false
        Toast.makeText(activity, "悬浮窗已关闭", Toast.LENGTH_SHORT).show()
        return
    end
    if not 卡密已加载 then
        Toast.makeText(activity, "正在同步卡密，请稍等...", Toast.LENGTH_SHORT).show()
        return
    end
    local 输入密码 = 卡密输入.getText().toString()
    if 输入密码 == "" then
        if 本地卡密有效() then
            wmManager.addView(悬浮球, wmParams)
            Ma = true
            Toast.makeText(activity, "登录成功（本地卡密），悬浮窗已开启", Toast.LENGTH_SHORT).show()
            启动卡密倒计时()
        else
            Toast.makeText(activity, "请输入卡密！", Toast.LENGTH_SHORT).show()
        end
        return
    end
    local 有效, 信息, 最大设备, 真实过期 = 卡密有效(输入密码)
    if 有效 then
        卡密存储.edit()
            .putString("auth_key", 输入密码)
            .putLong("expires", 真实过期)
            .apply()
        已保存卡密 = 输入密码
        卡密过期 = 真实过期
        wmManager.addView(悬浮球, wmParams)
        Ma = true
        Toast.makeText(activity, "登录成功，悬浮窗已开启", Toast.LENGTH_SHORT).show()
        启动卡密倒计时()
    else
        Toast.makeText(activity, "卡密验证失败: " .. 信息, Toast.LENGTH_LONG).show()
    end
end

解绑.onClick = function(v)
    if 已保存卡密 == "" and not 本地卡密有效() then
        Toast.makeText(activity, "当前未绑定卡密", Toast.LENGTH_SHORT).show()
        return
    end
    AlertDialog.Builder(activity)
        .setTitle("确认解绑")
        .setMessage("解绑后需要重新输入卡密才能使用，是否继续？")
        .setPositiveButton("解绑", {onClick=function()
            卡密存储.edit()
                .remove("auth_key")
                .remove("expires")
                .apply()
            已保存卡密 = ""
            卡密过期 = 0
            if Ma then
                pcall(function() wmManager.removeView(悬浮球) end)
                Ma = false
            end
            if 倒计时Runnable then
                全局Handler.removeCallbacks(倒计时Runnable)
            end
            Toast.makeText(activity, "卡密已解绑，请重新登录", Toast.LENGTH_SHORT).show()
        end})
        .setNegativeButton("取消", nil)
        .show()
end

-- ========== 频道按钮 ==========
频道.onClick = function(v)
    pcall(function()
        import "android.content.Intent"
        import "android.net.Uri"
        local intent = Intent(Intent.ACTION_VIEW)
        intent.setData(Uri.parse("https://pd.qq.com/s/6g067ly1b"))
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        activity.startActivity(intent)
    end)
end

-- ========== 购买按钮 ==========
购买按钮.onClick = function(v)
    pcall(function()
        import "android.content.Intent"
        import "android.net.Uri"
        local intent = Intent(Intent.ACTION_VIEW)
        intent.setData(Uri.parse("https://pd.qq.com/s/6g067ly1b"))
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        activity.startActivity(intent)
    end)
end

-- ========== 华为P40 Pro/HarmonyOS保活提示 ==========
function 华为保活提示()
    pcall(function()
        import "android.os.Build"
        local manufacturer = Build.MANUFACTURER:lower()
        if manufacturer:find("huawei") or manufacturer:find("honor") then
            local 偏好 = activity.getSharedPreferences("huawei_tip", Context.MODE_PRIVATE)
            if not 偏好.getBoolean("shown", false) then
                AlertDialog.Builder(activity)
                    .setTitle("华为/荣耀设备保活指南")
                    .setMessage("检测到您使用华为/荣耀设备（如P40 Pro），为确保悬浮窗长期存活，请完成以下设置：\n\n1. 设置 → 电池 → 应用启动管理 → 找到本应用 → 手动管理 → 允许后台活动 + 允许自启动\n2. 设置 → 应用和服务 → 应用管理 → 本应用 → 权限 → 悬浮窗 → 始终允许\n3. 最近任务界面 → 下拉本应用卡片锁定（或点击🔒图标）\n4. 设置 → 通知 → 本应用 → 允许通知\n\nHarmonyOS系统可能会限制后台活动，请务必设置！")
                    .setPositiveButton("去设置", {onClick=function()
                        偏好.edit().putBoolean("shown", true).apply()
                        local intent = Intent("android.settings.APPLICATION_DETAILS_SETTINGS")
                        intent.setData(Uri.parse("package:" .. activity.getPackageName()))
                        pcall(function() activity.startActivity(intent) end)
                    end})
                    .setNegativeButton("我知道了", {onClick=function()
                        偏好.edit().putBoolean("shown", true).apply()
                    end})
                    .setCancelable(false)
                    .show()
            end
        end
    end)
end

华为保活提示()

-- 设置边框
设置边框 = function(view, Thickness, FrameColor, InsideColor, radiu)
  import "android.graphics.drawable.GradientDrawable"
  drawable = GradientDrawable()
  drawable.setShape(GradientDrawable.RECTANGLE)
  drawable.setStroke(Thickness, FrameColor)
  drawable.setColor(InsideColor)
  drawable.setCornerRadii({radiu, radiu, radiu, radiu, radiu, radiu, radiu, radiu})
  view.setBackground(drawable)
end

设置边框(卡片, 5, 0xFF70858D, 0x9BFFFFFF, 0)
设置边框(背景, 5, 0xFF70858D, 0x00000000, 0)
设置边框(缩小, 5, 0xFF70858D, 0x00000000, 0)
