-- 如果有更新包，优先加载更新后的脚本（必须放在 require "import" 之前）
local File = luajava.bindClass("java.io.File")
local 更新目录 = activity.getFilesDir().getAbsolutePath() .. "/update"
local 更新主文件 = 更新目录 .. "/main.lua"
if File(更新主文件).exists() then
  activity.setLuaDir(更新目录)
  dofile(更新主文件)
  return
end

require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "com.pretend.eq.view.*"
import "layout"
import "AndLua"
import "xfq"
import "xfc"

-- ========== 云更新（启动时自动检查）==========
-- GitHub raw 地址，国内建议用 ghproxy 加速
local 更新服务器 = "https://ghproxy.com/https://raw.githubusercontent.com/78zhege-ctrl/myapp-update/main/"
-- 本地版本号（每次发新版记得改这里，要和仓库的 version.txt 一致）
local 本地版本 = "1.0"

-- 检查更新（异步，不阻塞启动）
function 检查更新()
  import "java.net.URL"
  import "java.io.BufferedReader"
  import "java.io.InputStreamReader"

  task(function(服务器, 版本)
    import "java.net.URL"
    import "java.io.BufferedReader"
    import "java.io.InputStreamReader"

    local 最新版本 = nil
    local ok, err = pcall(function()
      local url = URL(服务器 .. "version.txt")
      local conn = url.openConnection()
      conn.setConnectTimeout(5000)
      conn.setReadTimeout(5000)
      local reader = BufferedReader(InputStreamReader(conn.getInputStream()))
      最新版本 = reader.readLine()
      reader.close()
    end)

    return {最新版本, ok}
  end, function(结果)
    local 最新版本 = 结果[1]
    local 成功 = 结果[2]

    if 成功 and 最新版本 then
      最新版本 = 最新版本:gsub("%s", "")
      if 最新版本 ~= 本地版本 then
        AlertDialog.Builder(activity)
        .setTitle("发现新版本 v" .. 最新版本)
        .setMessage("当前版本: v" .. 本地版本 .. "\n是否立即更新？")
        .setPositiveButton("更新", {onClick=function()
            下载更新包()
          end})
        .setNegativeButton("取消", nil)
        .show()
      end
    else
      print("更新检查失败")
    end
  end, 更新服务器, 本地版本)
end

-- 下载更新包
function 下载更新包()
  import "android.app.ProgressDialog"
  local 进度 = ProgressDialog.show(activity, "更新中", "正在下载最新版本...", true, false)

  task(function(服务器)
    import "java.net.URL"
    import "java.io.File"
    import "java.io.FileOutputStream"
    import "java.io.BufferedInputStream"

    local 下载路径 = activity.getFilesDir().getAbsolutePath() .. "/update.zip"
    local ok = false

    pcall(function()
      local url = URL(服务器 .. "update.zip")
      local conn = url.openConnection()
      conn.setConnectTimeout(10000)
      conn.setReadTimeout(10000)

      local input = BufferedInputStream(conn.getInputStream())
      local output = FileOutputStream(下载路径)

      local buffer = byte[1024]
      local count = 0
      while true do
        count = input.read(buffer)
        if count == -1 then break end
        output.write(buffer, 0, count)
      end

      output.flush()
      output.close()
      input.close()
      ok = true
    end)

    return {下载路径, ok}
  end, function(结果)
    local 路径 = 结果[1]
    local 成功 = 结果[2]
    进度.dismiss()

    if 成功 then
      解压更新包(路径)
    else
      Toast.makeText(activity, "下载失败，请检查网络", Toast.LENGTH_SHORT).show()
    end
  end, 更新服务器)
end

-- 解压并替换
function 解压更新包(路径)
  import "java.util.zip.ZipFile"
  import "java.io.File"
  import "java.io.FileOutputStream"

  local 进度 = ProgressDialog.show(activity, "更新中", "正在安装...", true, false)

  task(function(路径)
    local 项目目录 = activity.getFilesDir().getAbsolutePath() .. "/update"
    local ok = false

    pcall(function()
      -- 先清空旧更新目录
      local dir = File(项目目录)
      if dir.exists() then
        local files = dir.listFiles()
        if files then
          for i = 0, #files - 1 do
            files[i].delete()
          end
        end
      else
        dir.mkdirs()
      end

      local zip = ZipFile(路径)
      local entries = zip.entries()

      while entries.hasMoreElements() do
        local entry = entries.nextElement()
        local 文件名 = entry.getName()
        local 输出文件 = File(项目目录 .. "/" .. 文件名)

        if not 输出文件.getParentFile().exists() then
          输出文件.getParentFile().mkdirs()
        end

        local input = zip.getInputStream(entry)
        local output = FileOutputStream(输出文件)
        local buffer = byte[1024]
        local count = 0
        while true do
          count = input.read(buffer)
          if count == -1 then break end
          output.write(buffer, 0, count)
        end
        output.close()
        input.close()
      end

      zip.close()
      ok = true
    end)

    return ok
  end, function(成功)
    进度.dismiss()
    if 成功 then
      AlertDialog.Builder(activity)
      .setTitle("更新完成")
      .setMessage("重启应用后生效")
      .setPositiveButton("立即重启", {onClick=function()
          import "android.content.Intent"
          local intent = activity.getPackageManager().getLaunchIntentForPackage(activity.getPackageName())
          intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
          activity.startActivity(intent)
          activity.finish()
        end})
      .show()
    else
      Toast.makeText(activity, "安装失败", Toast.LENGTH_SHORT).show()
    end
  end, 路径)
end

-- 启动时延迟检查更新
import "android.os.Handler"
Handler().postDelayed(function()
  检查更新()
end, 2000)
-- ========== 云更新结束 ==========

activity.setTheme(R.Theme_Blue)
activity.setContentView(loadlayout(layout))
activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS).setStatusBarColor(0xFF566B79)

activity.ActionBar.hide()

-- UI进入动画
import "android.animation.ObjectAnimator"
import "android.animation.AnimatorSet"
import "android.view.animation.BounceInterpolator"

local rootView = activity.findViewById(android.R.id.content).getChildAt(0)
rootView.setAlpha(0)
rootView.setScaleX(0.5)
rootView.setScaleY(0.5)

local alphaAnim = ObjectAnimator.ofFloat(rootView, "alpha", {0, 1})
local scaleXAnim = ObjectAnimator.ofFloat(rootView, "scaleX", {0.5, 1})
local scaleYAnim = ObjectAnimator.ofFloat(rootView, "scaleY", {0.5, 1})

local animatorSet = AnimatorSet()
animatorSet.playTogether({alphaAnim, scaleXAnim, scaleYAnim})
animatorSet.setDuration(1000)
animatorSet.setInterpolator(BounceInterpolator())
animatorSet.start()

-- 悬浮窗权限
import "android.content.*"
import "android.provider.Settings"
if Build.VERSION.SDK_INT >= 23 and (not Settings.canDrawOverlays(this)) then
  import "android.net.*"
  AlertDialog.Builder()
  .setTitle("没有悬浮窗权限！")
  .setMessage("检测到您没有给予悬浮窗权限，请点击授权。")
  .setPositiveButton("授权",{onClick=function(v)
      intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
      intent.setData(Uri.parse("package:" .. activity.getPackageName()));
      activity.startActivityForResult(intent, 100);
    end})
  .show()
end

-- 悬浮窗设置
wmManager = activity.getSystemService(Context.WINDOW_SERVICE)
wmParams = WindowManager.LayoutParams()

if tonumber(Build.VERSION.SDK) >= 26 then
  wmParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
else
  wmParams.type = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
end

import "android.graphics.PixelFormat"
wmParams.format = PixelFormat.RGBA_8888
wmParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE 
               | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
wmParams.gravity = Gravity.LEFT | Gravity.TOP
wmParams.x = activity.getWidth()/6
wmParams.y = activity.getHeight()/5
wmParams.width = WindowManager.LayoutParams.WRAP_CONTENT
wmParams.height = WindowManager.LayoutParams.WRAP_CONTENT

悬浮球 = loadlayout(xfq)
悬浮窗 = loadlayout(xfc)

-- 悬浮窗弹性动画
function 播放悬浮窗动画(view)
  import "android.animation.ObjectAnimator"
  import "android.animation.AnimatorSet"
  import "android.view.animation.BounceInterpolator"
  view.setAlpha(0)
  view.setScaleX(0.3)
  view.setScaleY(0.3)
  local a = ObjectAnimator.ofFloat(view, "alpha", {0, 1})
  local sx = ObjectAnimator.ofFloat(view, "scaleX", {0.3, 1})
  local sy = ObjectAnimator.ofFloat(view, "scaleY", {0.3, 1})
  local set = AnimatorSet()
  set.playTogether({a, sx, sy})
  set.setDuration(800)
  set.setInterpolator(BounceInterpolator())
  set.start()
end

function 放大()
  wmManager.addView(悬浮窗, wmParams)
  播放悬浮窗动画(悬浮窗)
  wmManager.removeView(悬浮球)
  检测Root()
end

缩小.onClick = function(v)
  wmManager.removeView(悬浮窗)
  wmManager.addView(悬浮球, wmParams)
end

关闭悬浮窗.onClick = function(v)
  pcall(function() wmManager.removeView(悬浮窗) end)
  pcall(function() wmManager.removeView(悬浮球) end)
  Ma = false
  QQ开关.setChecked(false)
  功能开启状态 = false
  功能开启.getChildAt(0).setText("OFF")
  Toast.makeText(activity, "悬浮窗已关闭", Toast.LENGTH_SHORT).show()
end

图标.onTouch = function(v, event)
  if event.getAction() == MotionEvent.ACTION_DOWN then
    firstX = event.getRawX()
    firstY = event.getRawY()
    wmX = wmParams.x
    wmY = wmParams.y
  elseif event.getAction() == MotionEvent.ACTION_MOVE then
    wmParams.x = wmX + (event.getRawX() - firstX)
    wmParams.y = wmY + (event.getRawY() - firstY)
    wmManager.updateViewLayout(悬浮球, wmParams)
  end
  return false
end

拖动.onTouch = function(v, event)
  if event.getAction() == MotionEvent.ACTION_DOWN then
    firstX = event.getRawX()
    firstY = event.getRawY()
    wmX = wmParams.x
    wmY = wmParams.y
  elseif event.getAction() == MotionEvent.ACTION_MOVE then
    wmParams.x = wmX + (event.getRawX() - firstX)
    wmParams.y = wmY + (event.getRawY() - firstY)
    wmManager.updateViewLayout(悬浮窗, wmParams)
  end
  return false
end

winParams = 卡片.getLayoutParams()
win_worh.onTouch = function(v, event)
  if event.getAction() == MotionEvent.ACTION_DOWN then
    firstX = event.getRawX()
    firstY = event.getRawY()
    wmX = winParams.width
    wmY = winParams.height
  elseif event.getAction() == MotionEvent.ACTION_MOVE then
    winParams.width = wmX + (event.getRawX() - firstX)
    winParams.height = wmY + (event.getRawY() - firstY)
    卡片.setLayoutParams(winParams)
  end
  return true
end

-- Root检测
function 检测Root()
  import "java.io.File"
  local suPaths = {
    "/system/bin/su",
    "/system/xbin/su",
    "/sbin/su",
    "/su/bin/su",
    "/data/local/xbin/su",
    "/data/local/bin/su",
    "/system/sbin/su",
    "/vendor/bin/su"
  }
  local hasRoot = false
  for i, path in ipairs(suPaths) do
    local file = File(path)
    if file.exists() then
      hasRoot = true
      break
    end
  end
  if not hasRoot then
    local ok, err = pcall(function()
      import "java.lang.Runtime"
      local process = Runtime.getRuntime().exec("su -c id")
      process.waitFor()
      if process.exitValue() == 0 then
        hasRoot = true
      end
    end)
  end
  if hasRoot then
    Root状态.setText("已获取 ✓")
    Root状态.setTextColor(0xFF00FF00)
  else
    Root状态.setText("未获取 ✗")
    Root状态.setTextColor(0xFFFF0000)
  end
end

-- QQ开关：原生Switch
QQ开关.setOnCheckedChangeListener{
  onCheckedChanged=function(view, isChecked)
    if isChecked then
      import "android.content.Intent"
      import "android.content.pm.PackageManager"
      import "android.net.Uri"
      local pm = activity.getPackageManager()
      local qqPackages = {
        "com.tencent.mobileqq",
        "com.tencent.mobileqqi",
        "com.tencent.qqlite"
      }
      local qqFound = false
      for i, pkg in ipairs(qqPackages) do
        local qqIntent = pm.getLaunchIntentForPackage(pkg)
        if qqIntent then
          qqIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
          qqIntent.addFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
          local ok, err = pcall(function()
            activity.startActivity(qqIntent)
          end)
          if ok then
            qqFound = true
            Toast.makeText(activity, "正在打开QQ", Toast.LENGTH_SHORT).show()
            break
          end
        end
      end
      if not qqFound then
        local uriIntent = Intent(Intent.ACTION_VIEW)
        uriIntent.setData(Uri.parse("mqq://"))
        uriIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        local resolve = pm.resolveActivity(uriIntent, 0)
        if resolve then
          local ok2, err2 = pcall(function()
            activity.startActivity(uriIntent)
          end)
          if ok2 then
            qqFound = true
            Toast.makeText(activity, "正在打开QQ", Toast.LENGTH_SHORT).show()
          end
        end
      end
      if not qqFound then
        local webIntent = Intent(Intent.ACTION_VIEW)
        webIntent.setData(Uri.parse("https://im.qq.com"))
        webIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        pcall(function()
          activity.startActivity(webIntent)
        end)
        Toast.makeText(activity, "未安装QQ，已跳转官网", Toast.LENGTH_SHORT).show()
        QQ开关.setChecked(false)
      end
    end
  end
}

-- 功能开启按钮
功能开启状态 = false
功能开启.onClick = function(v)
  if 功能开启状态 == false then
    v.getChildAt(0).setText("ON")
    功能开启状态 = true
    Toast.makeText(activity, "功能已开启", Toast.LENGTH_SHORT).show()
  else
    v.getChildAt(0).setText("OFF")
    功能开启状态 = false
    Toast.makeText(activity, "功能已关闭", Toast.LENGTH_SHORT).show()
  end
end

-- 选进程
选进程.onClick = function(v)
  Toast.makeText(activity, "注入功能开发中...", Toast.LENGTH_SHORT).show()
end

-- 密码验证（已改为810520）
Ma = false
开启.onClick = function()
  local 输入密码 = 卡密输入.getText().toString()
  if 输入密码 ~= "810520" then
    Toast.makeText(activity, "卡密错误！", Toast.LENGTH_SHORT).show()
    return
  end
  if Ma == false then
    wmManager.addView(悬浮球, wmParams)
    Ma = true
    Toast.makeText(activity, "登录成功，悬浮窗已开启", Toast.LENGTH_SHORT).show()
  else
    wmManager.removeView(悬浮球)
    Ma = false
    Toast.makeText(activity, "悬浮窗已关闭", Toast.LENGTH_SHORT).show()
  end
end

-- 设置边框
设置边框 = function(view, Thickness, FrameColor, InsideColor, radiu)
  import "android.graphics.drawable.GradientDrawable"
  drawable = GradientDrawable()
  drawable.setShape(GradientDrawable.RECTANGLE)
  drawable.setStroke(Thickness, FrameColor)
  drawable.setColor(InsideColor)
  drawable.setCornerRadii({radiu, radiu, radiu, radiu, radiu, radiu, radiu, radiu})
  view.setBackground(drawable)
end

设置边框(卡片, 5, 0xFF70858D, 0x9BFFFFFF, 0)
设置边框(背景, 5, 0xFF70858D, 0x00000000, 0)
设置边框(缩小, 5, 0xFF70858D, 0x00000000, 0)
