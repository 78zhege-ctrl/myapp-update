-- 如果有更新包，优先加载更新后的脚本（必须放在 require "import" 之前）
local File = luajava.bindClass("java.io.File")
local 更新目录 = activity.getFilesDir().getAbsolutePath() .. "/update"
local 更新主文件 = 更新目录 .. "/main.lua"
if File(更新主文件).exists() then
  activity.setLuaDir(更新目录)
  dofile(更新主文件)
  return
end

require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "com.pretend.eq.view.*"
import "layout"
import "AndLua"
import "xfq"
import "xfc"

-- ========== 智能云更新（静默后台检查）==========
local 更新服务器 = "https://ghproxy.net/https://raw.githubusercontent.com/78zhege-ctrl/myapp-update/main/"
local 本地版本 = "1.1"

-- 智能间隔策略：
-- 首次启动不检查，第3次启动开始检查
-- 检查成功且版本相同 → 7天后再检查
-- 检查失败/超时 → 1天后再试（指数退避：1天→3天→7天）
-- 发现新版本 → 立即提示
function 检查更新()
    import "android.content.Context"
    local 偏好设置 = activity.getSharedPreferences("update", Context.MODE_PRIVATE)
    local 启动次数 = 偏好设置.getInt("launch_count", 0) + 1
    偏好设置.edit().putInt("launch_count", 启动次数).apply()

    -- 前2次启动不检查，让用户先体验
    if 启动次数 < 3 then
        return
    end

    local 上次检查 = 偏好设置.getLong("last_check", 0)
    local 失败次数 = 偏好设置.getInt("fail_count", 0)
    local 当前时间 = System.currentTimeMillis()

    -- 计算下次检查间隔（根据失败次数指数退避）
    local 间隔小时 = 168  -- 默认7天
    if 失败次数 > 0 then
        local 退避 = {24, 72, 168}  -- 1天, 3天, 7天
        间隔小时 = 退避[math.min(失败次数, 3)]
    end

    if (当前时间 - 上次检查) < (间隔小时 * 3600000) then
        return
    end

    -- 静默后台检查，不弹窗，不阻塞UI
    task(function(服务器地址)
        import "java.net.URL"
        import "java.io.BufferedReader"
        import "java.io.InputStreamReader"

        local 版本 = ""
        local 成功 = false

        local ok, err = pcall(function()
            local url = URL(服务器地址 .. "version.txt")
            local conn = url.openConnection()
            conn.setConnectTimeout(5000)   -- 5秒连接超时
            conn.setReadTimeout(5000)        -- 5秒读取超时
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10)")
            conn.setInstanceFollowRedirects(true)

            if conn.getResponseCode() == 200 then
                local reader = BufferedReader(InputStreamReader(conn.getInputStream()))
                版本 = reader.readLine() or ""
                reader.close()
                成功 = true
            end
            conn.disconnect()
        end)

        return {成功, 版本, err}
    end, function(结果)
        local 请求成功 = 结果[1]
        local 最新版本 = 结果[2]
        local 错误信息 = 结果[3]

        if 请求成功 then
            最新版本 = 最新版本:gsub("%s", "")
            偏好设置.edit()
                .putLong("last_check", System.currentTimeMillis())
                .putInt("fail_count", 0)
                .apply()

            if 最新版本 ~= "" and 最新版本 ~= 本地版本 then
                -- 只有发现新版本才弹窗，平时完全静默
                AlertDialog.Builder(activity)
                    .setTitle("发现新版本 v" .. 最新版本)
                    .setMessage("当前版本: v" .. 本地版本 .. "\n是否立即更新？")
                    .setPositiveButton("更新", {onClick=function()
                        下载更新包()
                    end})
                    .setNegativeButton("暂不", nil)
                    .show()
            end
        else
            -- 失败，增加失败计数，下次延长间隔
            local 新失败次数 = 偏好设置.getInt("fail_count", 0) + 1
            偏好设置.edit()
                .putLong("last_check", System.currentTimeMillis())
                .putInt("fail_count", 新失败次数)
                .apply()
        end
    end, 更新服务器)
end

function 手动检查更新()
    local 检查弹窗 = ProgressDialog.show(activity, "检查更新", "正在连接服务器...", true, false)

    task(function(服务器地址)
        import "java.net.URL"
        import "java.io.BufferedReader"
        import "java.io.InputStreamReader"

        local 版本 = ""
        local 成功 = false

        local ok, err = pcall(function()
            local url = URL(服务器地址 .. "version.txt")
            local conn = url.openConnection()
            conn.setConnectTimeout(8000)
            conn.setReadTimeout(8000)
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10)")
            conn.setInstanceFollowRedirects(true)

            if conn.getResponseCode() == 200 then
                local reader = BufferedReader(InputStreamReader(conn.getInputStream()))
                版本 = reader.readLine() or ""
                reader.close()
                成功 = true
            end
            conn.disconnect()
        end)

        return {成功, 版本, err}
    end, function(结果)
        pcall(function() 检查弹窗.dismiss() end)

        local 请求成功 = 结果[1]
        local 最新版本 = 结果[2]
        local 错误信息 = 结果[3]

        if 请求成功 then
            最新版本 = 最新版本:gsub("%s", "")
            if 最新版本 ~= "" and 最新版本 ~= 本地版本 then
                AlertDialog.Builder(activity)
                    .setTitle("发现新版本 v" .. 最新版本)
                    .setMessage("当前版本: v" .. 本地版本 .. "\n是否立即更新？")
                    .setPositiveButton("更新", {onClick=function()
                        下载更新包()
                    end})
                    .setNegativeButton("取消", nil)
                    .show()
            else
                AlertDialog.Builder(activity)
                    .setTitle("已是最新版本")
                    .setMessage("当前版本: v" .. 本地版本)
                    .setPositiveButton("确定", nil)
                    .show()
            end
        else
            AlertDialog.Builder(activity)
                .setTitle("检查失败")
                .setMessage("连接服务器失败，请检查网络或稍后再试。\n错误: " .. tostring(错误信息))
                .setPositiveButton("确定", nil)
                .show()
        end
    end, 更新服务器)
end

function 下载更新包()
    import "android.app.ProgressDialog"
    local 进度 = ProgressDialog.show(activity, "更新中", "开始下载...", true, false)
    local 下载路径 = activity.getFilesDir().getAbsolutePath() .. "/update.zip"

    task(function(服务器, 进度对象)
        import "java.net.URL"
        import "java.io.File"
        import "java.io.FileOutputStream"
        import "java.io.BufferedInputStream"
        import "java.lang.Thread"

        local ok = false
        local 错误信息 = ""

        local 成功, 结果 = pcall(function()
            local oldFile = File(下载路径)
            if oldFile.exists() then oldFile.delete() end

            local url = URL(服务器 .. "update.zip")
            local conn = url.openConnection()
            conn.setConnectTimeout(30000)
            conn.setReadTimeout(30000)
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10)")

            local total = conn.getContentLength()
            local input = BufferedInputStream(conn.getInputStream())
            local output = FileOutputStream(下载路径)

            local buffer = byte[4096]
            local downloaded = 0
            local count = 0
            local lastUpdate = 0

            while true do
                count = input.read(buffer)
                if count == -1 then break end
                output.write(buffer, 0, count)
                downloaded = downloaded + count

                if downloaded - lastUpdate > 20480 then
                    lastUpdate = downloaded
                    if total > 0 then
                        local percent = math.floor(downloaded * 100 / total)
                        activity.runOnUiThread(function()
                            进度对象.setMessage("正在下载 " .. percent .. "%")
                        end)
                    else
                        activity.runOnUiThread(function()
                            进度对象.setMessage("正在下载 " .. math.floor(downloaded/1024) .. "KB")
                        end)
                    end
                end
            end

            output.flush()
            output.close()
            input.close()
            return true
        end)

        if not 成功 then
            错误信息 = tostring(结果)
        end

        return {下载路径, 成功, 错误信息}
    end, function(结果)
        local 路径 = 结果[1]
        local 成功 = 结果[2]
        local 错误 = 结果[3]

        if 成功 then
            进度.setMessage("下载完成，准备安装...")
            解压更新包(路径, 进度)
        else
            进度.dismiss()
            Toast.makeText(activity, "下载失败: " .. 错误, Toast.LENGTH_LONG).show()
        end
    end, 更新服务器, 进度)
end

function 解压更新包(路径, 进度)
    import "java.util.zip.ZipFile"
    import "java.io.File"
    import "java.io.FileOutputStream"
    import "java.lang.Thread"

    task(function(路径, 进度对象)
        local 项目目录 = activity.getFilesDir().getAbsolutePath() .. "/update"
        local ok = false
        local 错误信息 = ""

        local 成功, 结果 = pcall(function()
            local dir = File(项目目录)
            if dir.exists() then
                local files = dir.listFiles()
                if files then
                    for i = 0, #files - 1 do
                        files[i].delete()
                    end
                end
            else
                dir.mkdirs()
            end

            local zip = ZipFile(路径)
            local entries = zip.entries()

            local entryList = {}
            while entries.hasMoreElements() do
                table.insert(entryList, entries.nextElement())
            end

            local total = #entryList

            for i, entry in ipairs(entryList) do
                local 文件名 = entry.getName()
                local 输出文件 = File(项目目录 .. "/" .. 文件名)

                if not 输出文件.getParentFile().exists() then
                    输出文件.getParentFile().mkdirs()
                end

                local input = zip.getInputStream(entry)
                local output = FileOutputStream(输出文件)
                local buffer = byte[1024]
                local count = 0
                while true do
                    count = input.read(buffer)
                    if count == -1 then break end
                    output.write(buffer, 0, count)
                end
                output.close()
                input.close()

                activity.runOnUiThread(function()
                    进度对象.setMessage("正在安装 " .. i .. " / " .. total)
                end)

                Thread.sleep(50)
            end

            zip.close()
            return true
        end)

        if not 成功 then
            错误信息 = tostring(结果)
        end

        pcall(function()
            File(路径).delete()
        end)

        return {成功, 错误信息}
    end, function(结果)
        local 成功 = 结果[1]
        local 错误 = 结果[2]
        进度.dismiss()

        if 成功 then
            AlertDialog.Builder(activity)
            .setTitle("更新完成")
            .setMessage("重启应用后生效")
            .setPositiveButton("立即重启", {onClick=function()
                import "android.content.Intent"
                local intent = activity.getPackageManager().getLaunchIntentForPackage(activity.getPackageName())
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                activity.startActivity(intent)
                activity.finish()
            end})
            .show()
        else
            Toast.makeText(activity, "安装失败: " .. 错误, Toast.LENGTH_LONG).show()
        end
    end, 路径, 进度)
end

-- 启动2秒后在后台静默检查，用户完全无感知
import "android.os.Handler"
Handler().postDelayed(function()
    检查更新()
end, 2000)
-- ========== 云更新结束 ==========

activity.setTheme(R.Theme_Blue)
activity.setContentView(loadlayout(layout))
activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS).setStatusBarColor(0xFF566B79)

activity.ActionBar.hide()

-- UI进入动画
import "android.animation.ObjectAnimator"
import "android.animation.AnimatorSet"
import "android.view.animation.BounceInterpolator"

local rootView = activity.findViewById(android.R.id.content).getChildAt(0)
rootView.setAlpha(0)
rootView.setScaleX(0.5)
rootView.setScaleY(0.5)

local alphaAnim = ObjectAnimator.ofFloat(rootView, "alpha", {0, 1})
local scaleXAnim = ObjectAnimator.ofFloat(rootView, "scaleX", {0.5, 1})
local scaleYAnim = ObjectAnimator.ofFloat(rootView, "scaleY", {0.5, 1})

local animatorSet = AnimatorSet()
animatorSet.playTogether({alphaAnim, scaleXAnim, scaleYAnim})
animatorSet.setDuration(1000)
animatorSet.setInterpolator(BounceInterpolator())
animatorSet.start()

-- 悬浮窗权限（适配华为 EMUI / HarmonyOS）
import "android.content.*"
import "android.provider.Settings"
import "android.os.Build"
import "java.util.*"

function 检查悬浮窗权限()
    if Build.VERSION.SDK_INT >= 23 then
        local canDraw = Settings.canDrawOverlays(this)
        if not canDraw then
            AlertDialog.Builder(activity)
            .setTitle("需要悬浮窗权限")
            .setMessage("华为/荣耀系统请在「设置 → 应用和服务 → 应用管理 → 本应用 → 权限 → 悬浮窗」中开启权限。\n\n部分 HarmonyOS 版本需要同时开启「后台弹窗」权限。")
            .setPositiveButton("去开启", {onClick=function(v)
                -- 尝试跳转华为/原生设置页面
                local intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
                intent.setData(Uri.parse("package:" .. activity.getPackageName()))
                -- 华为 EMUI 可能不支持 ACTION_MANAGE_OVERLAY_PERMISSION，捕获异常
                local ok = pcall(function()
                    activity.startActivityForResult(intent, 100)
                end)
                if not ok then
                    --  fallback：跳转应用详情页
                    local intent2 = Intent("android.settings.APPLICATION_DETAILS_SETTINGS")
                    intent2.setData(Uri.parse("package:" .. activity.getPackageName()))
                    pcall(function() activity.startActivity(intent2) end)
                    Toast.makeText(activity, "请手动找到「悬浮窗」权限并开启", Toast.LENGTH_LONG).show()
                end
            end})
            .setNegativeButton("取消", nil)
            .show()
            return false
        end
    end
    return true
end

检查悬浮窗权限()

-- 悬浮窗设置
wmManager = activity.getSystemService(Context.WINDOW_SERVICE)
wmParams = WindowManager.LayoutParams()

if tonumber(Build.VERSION.SDK) >= 26 then
  wmParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
else
  wmParams.type = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
end

import "android.graphics.PixelFormat"
wmParams.format = PixelFormat.RGBA_8888
wmParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE 
               | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
wmParams.gravity = Gravity.LEFT | Gravity.TOP
wmParams.x = activity.getWidth()/6
wmParams.y = activity.getHeight()/5
wmParams.width = WindowManager.LayoutParams.WRAP_CONTENT
wmParams.height = WindowManager.LayoutParams.WRAP_CONTENT

悬浮球 = loadlayout(xfq)
悬浮窗 = loadlayout(xfc)

-- 悬浮窗弹性动画
function 播放悬浮窗动画(view)
  import "android.animation.ObjectAnimator"
  import "android.animation.AnimatorSet"
  import "android.view.animation.BounceInterpolator"
  view.setAlpha(0)
  view.setScaleX(0.3)
  view.setScaleY(0.3)
  local a = ObjectAnimator.ofFloat(view, "alpha", {0, 1})
  local sx = ObjectAnimator.ofFloat(view, "scaleX", {0.3, 1})
  local sy = ObjectAnimator.ofFloat(view, "scaleY", {0.3, 1})
  local set = AnimatorSet()
  set.playTogether({a, sx, sy})
  set.setDuration(800)
  set.setInterpolator(BounceInterpolator())
  set.start()
end

function 放大()
  wmManager.addView(悬浮窗, wmParams)
  播放悬浮窗动画(悬浮窗)
  wmManager.removeView(悬浮球)
  检测Root()
end

缩小.onClick = function(v)
  wmManager.removeView(悬浮窗)
  wmManager.addView(悬浮球, wmParams)
end

关闭悬浮窗.onClick = function(v)
  pcall(function() wmManager.removeView(悬浮窗) end)
  pcall(function() wmManager.removeView(悬浮球) end)
  Ma = false
  QQ开关.setChecked(false)
  功能开启状态 = false
  功能开启.getChildAt(0).setText("OFF")
  Toast.makeText(activity, "悬浮窗已关闭", Toast.LENGTH_SHORT).show()
end

图标.onTouch = function(v, event)
  if event.getAction() == MotionEvent.ACTION_DOWN then
    firstX = event.getRawX()
    firstY = event.getRawY()
    wmX = wmParams.x
    wmY = wmParams.y
  elseif event.getAction() == MotionEvent.ACTION_MOVE then
    wmParams.x = wmX + (event.getRawX() - firstX)
    wmParams.y = wmY + (event.getRawY() - firstY)
    wmManager.updateViewLayout(悬浮球, wmParams)
  end
  return false
end

拖动.onTouch = function(v, event)
  if event.getAction() == MotionEvent.ACTION_DOWN then
    firstX = event.getRawX()
    firstY = event.getRawY()
    wmX = wmParams.x
    wmY = wmParams.y
  elseif event.getAction() == MotionEvent.ACTION_MOVE then
    wmParams.x = wmX + (event.getRawX() - firstX)
    wmParams.y = wmY + (event.getRawY() - firstY)
    wmManager.updateViewLayout(悬浮窗, wmParams)
  end
  return false
end

winParams = 卡片.getLayoutParams()
win_worh.onTouch = function(v, event)
  if event.getAction() == MotionEvent.ACTION_DOWN then
    firstX = event.getRawX()
    firstY = event.getRawY()
    wmX = winParams.width
    wmY = winParams.height
  elseif event.getAction() == MotionEvent.ACTION_MOVE then
    winParams.width = wmX + (event.getRawX() - firstX)
    winParams.height = wmY + (event.getRawY() - firstY)
    卡片.setLayoutParams(winParams)
  end
  return true
end

-- Root检测
function 检测Root()
  import "java.io.File"
  local suPaths = {
    "/system/bin/su",
    "/system/xbin/su",
    "/sbin/su",
    "/su/bin/su",
    "/data/local/xbin/su",
    "/data/local/bin/su",
    "/system/sbin/su",
    "/vendor/bin/su"
  }
  local hasRoot = false
  for i, path in ipairs(suPaths) do
    local file = File(path)
    if file.exists() then
      hasRoot = true
      break
    end
  end
  if not hasRoot then
    local ok, err = pcall(function()
      import "java.lang.Runtime"
      local process = Runtime.getRuntime().exec("su -c id")
      process.waitFor()
      if process.exitValue() == 0 then
        hasRoot = true
      end
    end)
  end
  if hasRoot then
    Root状态.setText("已获取 ✓")
    Root状态.setTextColor(0xFF00FF00)
  else
    Root状态.setText("未获取 ✗")
    Root状态.setTextColor(0xFFFF0000)
  end
end

-- QQ开关：原生Switch
QQ开关.setOnCheckedChangeListener{
  onCheckedChanged=function(view, isChecked)
    if isChecked then
      import "android.content.Intent"
      import "android.content.pm.PackageManager"
      import "android.net.Uri"
      local pm = activity.getPackageManager()
      local qqPackages = {
        "com.tencent.mobileqq",
        "com.tencent.mobileqqi",
        "com.tencent.qqlite"
      }
      local qqFound = false
      for i, pkg in ipairs(qqPackages) do
        local qqIntent = pm.getLaunchIntentForPackage(pkg)
        if qqIntent then
          qqIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
          qqIntent.addFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
          local ok, err = pcall(function()
            activity.startActivity(qqIntent)
          end)
          if ok then
            qqFound = true
            Toast.makeText(activity, "正在打开QQ", Toast.LENGTH_SHORT).show()
            break
          end
        end
      end
      if not qqFound then
        local uriIntent = Intent(Intent.ACTION_VIEW)
        uriIntent.setData(Uri.parse("mqq://"))
        uriIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        local resolve = pm.resolveActivity(uriIntent, 0)
        if resolve then
          local ok2, err2 = pcall(function()
            activity.startActivity(uriIntent)
          end)
          if ok2 then
            qqFound = true
            Toast.makeText(activity, "正在打开QQ", Toast.LENGTH_SHORT).show()
          end
        end
      end
      if not qqFound then
        local webIntent = Intent(Intent.ACTION_VIEW)
        webIntent.setData(Uri.parse("https://im.qq.com"))
        webIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        pcall(function()
          activity.startActivity(webIntent)
        end)
        Toast.makeText(activity, "未安装QQ，已跳转官网", Toast.LENGTH_SHORT).show()
        QQ开关.setChecked(false)
      end
    end
  end
}

-- 功能开启按钮
功能开启状态 = false
功能开启.onClick = function(v)
  if 功能开启状态 == false then
    v.getChildAt(0).setText("ON")
    功能开启状态 = true
    Toast.makeText(activity, "功能已开启", Toast.LENGTH_SHORT).show()
  else
    v.getChildAt(0).setText("OFF")
    功能开启状态 = false
    Toast.makeText(activity, "功能已关闭", Toast.LENGTH_SHORT).show()
  end
end

-- 选进程
选进程.onClick = function(v)
  Toast.makeText(activity, "注入功能开发中...", Toast.LENGTH_SHORT).show()
end

-- 手动检查更新按钮
检查更新.onClick = function(v)
  手动检查更新()
end

-- ========== 卡密验证系统（GitHub远程卡密后台）==========
import "android.content.Context"
local 卡密存储 = activity.getSharedPreferences("key_auth", Context.MODE_PRIVATE)
local 已保存卡密 = 卡密存储.getString("auth_key", "")
local 卡密过期 = 卡密存储.getLong("expires", 0)
Ma = false

-- 远程卡密列表（从GitHub下载）
local 远程卡密列表 = {}
local 卡密已加载 = false

-- 解析卡密文本（安全版本，不用\n字符串）
function 解析卡密文本(content)
    local 列表 = {}
    if not content or content == "" then return 列表 end

    local newline = string.char(10)
    local start = 1
    while true do
        local pos = content:find(newline, start, true)
        local line
        if pos then
            line = content:sub(start, pos - 1)
            start = pos + 1
        else
            line = content:sub(start)
            if line == "" then break end
            start = #content + 1
        end

        -- 去掉末尾回车符
        if line:sub(-1) == string.char(13) then
            line = line:sub(1, -2)
        end

        -- 跳过注释和空行
        if not line:find("^#") and not line:find("^%s*$") then
            local key, expires, max = line:match("^([^|]+)|([^|]+)|(%d+)$")
            if key then
                key = key:gsub("%s", "")
                expires = expires:gsub("%s", "")
                列表[key] = {expires = expires, maxDevices = tonumber(max)}
            end
        end

        if not pos then break end
    end
    return 列表
end

-- 下载卡密列表（启动时调用）
function 下载卡密列表()
    local 随机数 = tostring(math.random(100000, 999999))
    local url = "https://ghproxy.net/https://raw.githubusercontent.com/78zhege-ctrl/myapp-update/main/keys.txt?t=" .. 随机数

    Http.get(url, function(code, content)
        if code == 200 and content and content ~= "" then
            远程卡密列表 = 解析卡密文本(content)
            卡密已加载 = true
            local 数量 = 0
            for _ in pairs(远程卡密列表) do 数量 = 数量 + 1 end
            print("卡密同步成功，共 " .. 数量 .. " 条")
        else
            print("卡密下载失败，使用内置默认")
            远程卡密列表 = {
                ["810520"] = {expires = "2099-12-31", maxDevices = 99},
                ["TEMP01"] = {expires = "2026-07-14", maxDevices = 1},
                ["TEMP02"] = {expires = "2026-07-14", maxDevices = 1}
            }
            卡密已加载 = true
        end
    end)
end

-- 检查卡密是否有效
function 卡密有效(卡密)
    local info = 远程卡密列表[卡密]
    if not info then return false, "卡密不存在" end

    if info.expires and info.expires ~= "" then
        local year, month, day = info.expires:match("(%d+)-(%d+)-(%d+)")
        if year then
            local expireTime = os.time({year=tonumber(year), month=tonumber(month), day=tonumber(day)})
            if expireTime < os.time() then
                return false, "卡密已过期"
            end
        end
    end

    return true, "有效", info.maxDevices
end

-- 检查本地卡密是否仍有效
function 本地卡密有效()
    if 已保存卡密 == "" then return false end
    if 卡密过期 > 0 and 卡密过期 < System.currentTimeMillis() then
        return false
    end
    local 有效, 信息 = 卡密有效(已保存卡密)
    return 有效
end

-- 登录按钮
开启.onClick = function()
    if Ma == true then
        pcall(function() wmManager.removeView(悬浮球) end)
        Ma = false
        Toast.makeText(activity, "悬浮窗已关闭", Toast.LENGTH_SHORT).show()
        return
    end

    if not 卡密已加载 then
        Toast.makeText(activity, "正在同步卡密，请稍等...", Toast.LENGTH_SHORT).show()
        return
    end

    local 输入密码 = 卡密输入.getText().toString()

    if 输入密码 == "" then
        if 本地卡密有效() then
            wmManager.addView(悬浮球, wmParams)
            Ma = true
            Toast.makeText(activity, "登录成功（本地卡密），悬浮窗已开启", Toast.LENGTH_SHORT).show()
        else
            Toast.makeText(activity, "请输入卡密！", Toast.LENGTH_SHORT).show()
        end
        return
    end

    local 有效, 信息, 最大设备 = 卡密有效(输入密码)
    if 有效 then
        卡密存储.edit()
            .putString("auth_key", 输入密码)
            .putLong("expires", System.currentTimeMillis() + 30*86400000)
            .apply()
        已保存卡密 = 输入密码
        卡密过期 = System.currentTimeMillis() + 30*86400000

        wmManager.addView(悬浮球, wmParams)
        Ma = true
        Toast.makeText(activity, "登录成功，悬浮窗已开启", Toast.LENGTH_SHORT).show()
    else
        Toast.makeText(activity, "卡密验证失败: " .. 信息, Toast.LENGTH_LONG).show()
    end
end

-- 解绑按钮
解绑.onClick = function(v)
    if 已保存卡密 == "" and not 本地卡密有效() then
        Toast.makeText(activity, "当前未绑定卡密", Toast.LENGTH_SHORT).show()
        return
    end

    AlertDialog.Builder(activity)
        .setTitle("确认解绑")
        .setMessage("解绑后需要重新输入卡密才能使用，是否继续？")
        .setPositiveButton("解绑", {onClick=function()
            卡密存储.edit()
                .remove("auth_key")
                .remove("expires")
                .apply()
            已保存卡密 = ""
            卡密过期 = 0
            if Ma then
                pcall(function() wmManager.removeView(悬浮球) end)
                Ma = false
            end
            Toast.makeText(activity, "卡密已解绑，请重新登录", Toast.LENGTH_SHORT).show()
        end})
        .setNegativeButton("取消", nil)
        .show()
end

-- 启动时下载卡密列表
下载卡密列表()
-- ========== 华为 EMUI/HarmonyOS 后台保活提示 ==========
-- 华为系统杀后台较激进，如需悬浮窗长期存活，建议：
-- 1. 设置 → 电池 → 应用启动管理 → 本应用 → 手动管理 → 允许后台活动 + 允许自启动
-- 2. 设置 → 应用和服务 → 应用管理 → 本应用 → 耗电详情 → 启动管理 → 手动管理
-- 3. 多任务界面（最近任务）→ 锁定本应用卡片（下滑或点击锁图标）
-- ========== 卡密验证结束 ==========

-- 设置边框
设置边框 = function(view, Thickness, FrameColor, InsideColor, radiu)
  import "android.graphics.drawable.GradientDrawable"
  drawable = GradientDrawable()
  drawable.setShape(GradientDrawable.RECTANGLE)
  drawable.setStroke(Thickness, FrameColor)
  drawable.setColor(InsideColor)
  drawable.setCornerRadii({radiu, radiu, radiu, radiu, radiu, radiu, radiu, radiu})
  view.setBackground(drawable)
end

设置边框(卡片, 5, 0xFF70858D, 0x9BFFFFFF, 0)
设置边框(背景, 5, 0xFF70858D, 0x00000000, 0)
设置边框(缩小, 5, 0xFF70858D, 0x00000000, 0)
